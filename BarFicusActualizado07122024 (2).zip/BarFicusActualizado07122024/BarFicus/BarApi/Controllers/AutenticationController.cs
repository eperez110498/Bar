﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SharedModels;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using BarApi.Services;
using DatabaseProyect;
using System.Text;

namespace BarApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutenticationController : ControllerBase
    {
        private readonly string secretKey;
        public AutenticationController(IConfiguration config)
        {
            secretKey = config.GetSection("settings").GetSection("secretkey").ToString();
        }

        [HttpPost]
        [Route("Validar")]
        public async Task<IActionResult> Validar([FromBody] Usuarios request)
        {
            try
            {
                // 1. Verificar si el correo existe en la base de datos
                var usuario = new Usuarios()
                {
                    Activo = true,
                    Nombre = request.Nombre,
                    Correo = "pepito@gmail.com",
                    Clave = "pepito123",
                    Id_Usuario = 1234,
                };
                // Si no existe el usuario, regresar Unauthorized
                if (usuario == null)
                {
                    return Unauthorized("Usuario no encontrado");
                }

         

                // 3. Generar el token JWT si el usuario y la contraseña son correctos
                var keyBytes = Encoding.ASCII.GetBytes(secretKey);
                var claims = new ClaimsIdentity();

                claims.AddClaim(new Claim(ClaimTypes.NameIdentifier, usuario.Correo));

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = claims,
                    Expires = DateTime.UtcNow.AddMinutes(10), // Expira en 10 minutos
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(keyBytes), SecurityAlgorithms.HmacSha256Signature)
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenConfig = tokenHandler.CreateToken(tokenDescriptor);

                string tokencreado = tokenHandler.WriteToken(tokenConfig);

                // Retornar el token si todo está correcto
                return StatusCode(StatusCodes.Status200OK, new { token = tokencreado });
            }
            catch
            {
                return StatusCode(StatusCodes.Status401Unauthorized, new { token = "" });
            }


             

        }

    }
}
    

