﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormularioApp;

using CredentialManagement;

public static class TokenManager
{
    private const string Target = "MyAppToken"; // Nombre del objetivo para el Administrador de Credenciales.

    /// <summary>
    /// Guarda el token en el Administrador de Credenciales .
    /// </summary>
    /// <param name="token">El token que deseas guardar.</param>
    public static void SaveToken(string token)
    {
        try
        {
            using (var cred = new Credential
            {
                Target = Target,
                Username = "User", // Nombre de usuario genérico.
                Password = token,
                Type = CredentialType.Generic,
            })
            {
                cred.Save();
                Console.WriteLine("Token guardado correctamente en el Administrador de Credenciales.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al guardar el token: {ex.Message}");
        }
    }

    /// <summary>
    /// Recupera el token del Administrador de Credenciales.
    /// </summary>
    /// <returns>El token si existe; de lo contrario, null.</returns>
    public static string GetToken()
    {
        try
        {
            using (var cred = new Credential { Target = Target })
            {
                if (cred.Load())
                {
                    Console.WriteLine("Token recuperado correctamente.");
                    return cred.Password;
                }
                else
                {
                    Console.WriteLine("No se encontró un token en el Administrador de Credenciales.");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al recuperar el token: {ex.Message}");
        }

        return null;
    }

    /// <summary>
    /// Elimina el token del Administrador de Credenciales.
    /// </summary>
    public static void DeleteToken()
    {
        try
        {
            using (var cred = new Credential { Target = Target })
            {
                if (cred.Delete())
                {
                    Console.WriteLine("Token eliminado correctamente del Administrador de Credenciales.");
                }
                else
                {
                    Console.WriteLine("No se encontró un token para eliminar.");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al eliminar el token: {ex.Message}");
        }
    }
}
